//
//  ViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/08/29.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit
import CoreLocation

var captureImage : UIImage?

class PostData: NSObject
{
    var id:Int?
    var name:String?
    var nameCount:Int?
    var totalCount:Int?
    var img:UIImage?
    var latitude:Double?
    var longitude:Double?
}

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    var locationManager:CLLocationManager = CLLocationManager()
    var ActivityIndicator: UIActivityIndicatorView!
    let button = UIButton()

    var posts = [PostData]()
    
    var myCoordinate:CLLocationCoordinate2D?
    
    func reload()
    {
        let client = URLSessionClient()
        client.get(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/list/10",
                   queryItems: nil) { (data) in
                   
                    self.posts = [PostData]()
                    
                    if let data = data as? [[String: Any]]
                    {
                        for elem in data
                        {
                            let post = PostData()
                            post.id = elem["id"] as? Int
                            
                            if let base64 = elem["img"] as? String
                            {
                                let base64_rep = base64.replacingOccurrences(of: " ", with: "+")
                                if let imgData = Data(base64Encoded: base64_rep, options: Data.Base64DecodingOptions.ignoreUnknownCharacters)
                                {
                                    let img = UIImage(data: imgData)
                                    post.img = img
                                }
                            }
                            
                            
                            if let names = elem["names"] as? [[String: Any]]
                            {
                                post.name = names[0]["name"] as? String
                                post.nameCount = names[0]["count"] as? Int
                            }
                            post.totalCount = elem["totalCount"] as? Int
                            
                            if let latitude = elem["latitude"] as? String
                            {
                                post.latitude = Double(latitude)
                            }
                            if let longitude = elem["longitude"] as? String
                            {
                                post.longitude = Double(longitude)
                            }
                            
                            self.posts.append(post)
                        }
                    }
                    
                    print("投稿を読み込みました")
                    
                    // メインスレッドで実行する
                    DispatchQueue.main.async {
                        self.tableView.reloadData()
                    }
                    
        }
    }
    
  override func viewDidLoad() {
    super.viewDidLoad()
    
    self.view.backgroundColor = UIColor.red
    // 現在地を取得する準備
    if (CLLocationManager.locationServicesEnabled())
    {
        
        self.locationManager.delegate = self
        self.locationManager.distanceFilter = kCLDistanceFilterNone
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
    }
    
    /*----------------ツールバー(カメラ)--------------*/
    button.setImage(UIImage(named:"カメラのアイコン素材 7"), for: .normal)
    button.frame = CGRect(x:0,y:0,width:60,height:60)
    button.layer.position = CGPoint(x: self.view.frame.width/2,y:self.view.frame.height-30)
    self.view.addSubview(button)
    button.addTarget(self, action: #selector(ViewController.launchCamera(_:)), for: .touchUpInside)
    button.showsTouchWhenHighlighted = true
    
    
    /*-----------------位置情報の認証---------------*/
    
    self.view.backgroundColor = UIColor.black
    
    //ナビゲーションアイテムのタイトルに画像を設定する。
    self.navigationItem.titleView = UIImageView(image:UIImage(named:"title-logo-min"))
  }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // データを読み込む
        self.reload()
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        switch status
        {
        case .notDetermined:
            self.locationManager.requestWhenInUseAuthorization()
            
        default:
            break
        }
    }
/*---------------------カメラ周りのプログラム----------------------------------*/
  
  //カメラアイコンをタップしたとき
    @objc func launchCamera(_ sender: Any) {
    
    //カメラが利用可能かチェック
    if UIImagePickerController.isSourceTypeAvailable(.camera){
        //カメラ起動
        let ipc : UIImagePickerController = UIImagePickerController()
        ipc.sourceType = .camera
        ipc.delegate = self
        self.present(ipc, animated: true, completion: nil)
      }
      
  }
  
  //撮影が終わった時に呼び出される
  func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
    
    //現在地を一度だけリクエストする
    locationManager.requestLocation()
    
    //保存のローディング画面の表示
    let progressHUD = ProgressHUD(text: "保存中")
    self.view.addSubview(progressHUD)
    self.view.backgroundColor = UIColor.black
    
    //撮影した画像をcaptureImageに渡す
    captureImage = info[UIImagePickerControllerOriginalImage] as? UIImage
    
    dismiss(animated: true, completion: nil)
 
  }
  
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?)
  {
        //次の画面のインスタンスを取得
        if segue.identifier == "showRegistrationView"
        {
            let nextViewController = segue.destination as! RegistrationViewController
    
            //次の画面のインスタンスに取得した画像を渡す
            nextViewController.originalImage = captureImage
            nextViewController.myCoordinate = self.myCoordinate

            
        //詳細ビューに移動する場合
        }
        else if segue.identifier == "showDetailView"
        {
                let nextViewController: DetailViewController = (segue.destination as? DetailViewController)!
                // DetailViewController のselectedImgに選択された画像を設定する
                if let selectedIndexPath = self.selectedIndexPath
                {
                    if let indexPath = self.selectedIndexPath
                    {
                        nextViewController.selectedImage = self.posts[indexPath.row].img!
                        nextViewController.postId = self.posts[indexPath.row].id!
                        nextViewController.no1NameStr = self.posts[indexPath.row].name
                        nextViewController.latitude = self.posts[indexPath.row].latitude
                        nextViewController.longitude = self.posts[indexPath.row].longitude
                    }
                    self.tableView.deselectRow(at: selectedIndexPath, animated: true)
                }
            
        //名付けるビューの場合
        }
        else if segue.identifier == "showNamedView"
        {
            let nextViewController = segue.destination as? namedViewController
            
            if let btn = sender as? UIButton
            {
                if let imgView = btn.superview?.viewWithTag(100) as? UIImageView
                {
                    nextViewController?.selectedImage = imgView.image
                }
                
                nextViewController?.postId = (btn.superview?.superview as? CustomTableViewCell)?.postId
            }
    }
    
}
    @IBAction func namedButtonAction(_ sender: Any)
    {
        self.performSegue(withIdentifier: "showNamedView", sender: sender)
    }
    
    //位置情報の取得に成功した場合
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        for location in locations {
            let myLatitude = location.coordinate.latitude
            let myLocation = location.coordinate.longitude
            
            self.myCoordinate = location.coordinate
            print("緯度:\(myLatitude)経度:\(myLocation)")

        }
        
            //登録画面へ移動
            self.performSegue(withIdentifier: "showRegistrationView", sender:nil)
        
    }
    
    //位置情報の取得に失敗した場合
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        
        print("位置情報の取得に失敗しました")
        
    }

  
/*-------------------画像表示周りのプログラム----------------------*/

  
  //セルの個数をimages配列の中身と同数に設定
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
//    return mainImageTitles.count
        return self.posts.count
  }
  
  //セルに値を設定するデータソースメソッド
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    //セルを取得
    let cell = tableView.dequeueReusableCell(withIdentifier: "ThumbnailCell") as! CustomTableViewCell

    let post = self.posts[indexPath.row]
    
    //セルに値を設定
    cell.postId = post.id
    cell.mainImageView.image = post.img!
    cell.mainImageTitle.text = post.name!
    cell.no1Count.text = post.nameCount?.description
    cell.totalCount.text = post.totalCount?.description
    
    return cell
    
  }
  
    //渡す画像を保管しておく
    var selectedIndexPath:IndexPath?
  
    //セルの中身を設定
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        self.selectedIndexPath = indexPath
        return indexPath
    
    }
    
}
