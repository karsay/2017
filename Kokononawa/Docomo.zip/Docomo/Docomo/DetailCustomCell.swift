//
//  DetailCustomCell.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/04.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class DetailCustomCell: UITableViewCell {
    
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var counter: UILabel!
    @IBOutlet weak var goodBtn: UIButton!
    
    var nameID:Int?
    var count = 0

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func goodButtonAction(_ sender: Any)
    {
        let btn = sender as? UIButton
        btn?.isEnabled = false
        
        if let nameID = self.nameID
        {
            let client = URLSessionClient()
            client.post(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/post",
                        parameters: ["name_id": nameID]) { (data) in
                            print(data)
            }
        }
    }

}
