//
//  namedViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/19.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class namedViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var namedImage: UIImageView!
    @IBOutlet weak var namdTextField: UITextField!
    var selectedImage: UIImage?
    var postId:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Text Fieldのdelegate通知先を自分に設定
        namdTextField.delegate = self
        
        namedImage.image = selectedImage

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        self.configureObserver()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        self.removeObserver()
        
    }
    
    func configureObserver() {
        
        let notification = NotificationCenter.default
        notification.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notification.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    }
    
    func removeObserver() {
        
        let notification = NotificationCenter.default
        notification.removeObserver(self)
        
    }
    @objc func keyboardWillShow(notification: Notification?) {
        
        let rect = (notification?.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        let duration: TimeInterval? = notification?.userInfo?[UIKeyboardAnimationDurationUserInfoKey] as? Double
        UIView.animate(withDuration: duration!, animations: { () in
            let transform = CGAffineTransform(translationX: 0, y: -(rect?.size.height)!)
            self.view.transform = transform
            
        })
    }
    
    // キーボードが消えたときに、画面を戻す
    @objc func keyboardWillHide(notification: Notification?) {
        
        let duration: TimeInterval? = notification?.userInfo?[UIKeyboardAnimationCurveUserInfoKey] as? Double
        UIView.animate(withDuration: duration!, animations: { () in
            
            self.view.transform = CGAffineTransform.identity
        })
    }
    
    //入力が完了した時に呼び出される
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //キーボードを閉じる
        namdTextField.resignFirstResponder()
        
        //入力された文字を取り出す
        let nameKeyWord = self.namdTextField.text
        print(nameKeyWord!)
        
        //デフォルド動作を行うためtrueを返す
        return true
        
    }
    @IBAction func canselButtonAction(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    //名付けるボタンを押した時の処理
    @IBAction func namedButtonAction(_ sender: Any)
    {
        if let postId = self.postId, let text = self.namdTextField.text
        {
            let client = URLSessionClient()
            client.post(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/name",
                        parameters: ["id": postId, "name": text]) { (data) in
                            print(data)
                            DispatchQueue.main.async {
                                self.dismiss(animated: true, completion: nil)
                            }
            }
        }
    }
    
}
