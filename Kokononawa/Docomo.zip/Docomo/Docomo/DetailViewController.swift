//
//  DetailViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/09/15.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class DetailViewController : UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var detailImage: UIImageView!
    @IBOutlet weak var no1Name: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var selectedImage : UIImage?
    //ブックマークボタン
    @IBOutlet weak var bookMarkButton: UIButton!
    var bookSwitch =  0
    var postId:Int?
    var latitude:Double?
    var longitude:Double?
    var no1NameStr:String?
    
    var nameIDs = [Int]()
    var names = [String]()
    var nameCounts = [Int]()

    func reload()
    {
        if let postId = self.postId?.description
        {
            let client = URLSessionClient()
            client.get(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/get/"+postId,
                       queryItems: nil) { (data) in

                        self.names = [String]()
                        self.nameCounts = [Int]()
                        
                        if let data = data as? [String: Any]
                        {
                            if let names = data["names"] as? [[String: Any]]
                            {
                                for name in names
                                {
                                    self.nameIDs.append(name["name_id"] as! Int)
                                    self.names.append(name["name"] as! String)
                                    self.nameCounts.append(name["count"] as! Int)
                                }
                            }
                        }
                        
                        DispatchQueue.main.async {
                            self.tableView.reloadData()
                        }
            }
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        //ViewControllerからの画像の受け皿
        detailImage.image = selectedImage
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
    
        self.no1Name.text = self.no1NameStr
        
        self.reload()
    }
    
    //ブックマークボタンをタップしたときの処理
    @IBAction func buttonTapped(sender : AnyObject)
    {
        if(bookSwitch == 0)
        {
            bookMarkButton.setImage(UIImage(named:"お気に入り、オススメに使える星アイコン。 (1)"), for: UIControlState())
            let alert0 = UIAlertController(title: "お気に入り登録しました",message:"",preferredStyle: .alert)
            self.present(alert0,animated: true,completion: {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                    alert0.dismiss(animated: true, completion: nil)
                })
            })
            
            bookSwitch += 1

        }
        else if(bookSwitch == 1)
        {
            bookMarkButton.setImage(UIImage(named:"お気に入り、オススメに使える星アイコン。 (1)-1"), for: UIControlState())
            
            let alert1 = UIAlertController(title: "登録を解除しました",message:"",preferredStyle: .alert)
            self.present(alert1,animated: true,completion:
            {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute:
                {
                    alert1.dismiss(animated: true, completion: nil)
                })
            })
            bookSwitch -= 1
        }
    }
    
    
    //テーブルのセルの数の設定
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        //セルの数をnameListの中身と同数に設定
        return self.names.count
    }
    
    //tableViewの必須メソッド(消去厳禁)
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DetailCustomCell

        cell.nameID = self.nameIDs[indexPath.row]
        cell.title.text = self.names[indexPath.row]
        cell.counter.text = self.nameCounts[indexPath.row].description
        
        return cell
    }
    
    //セルの選択解除
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if (segue.identifier == "goMap")
        {
            let nextViewController = segue.destination as! MapViewController
            nextViewController.longitude = self.longitude!
            nextViewController.latitude = self.latitude!
            
        }
    }
    
    
}
