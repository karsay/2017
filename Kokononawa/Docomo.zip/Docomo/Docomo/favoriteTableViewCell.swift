//
//  favoriteTableViewCell.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/19.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class favoriteTableViewCell: UITableViewCell {

    @IBOutlet weak var favoriteName: UILabel!
    @IBOutlet weak var favoriteImage: UIImageView!
    @IBOutlet weak var favoriteNo1Count: UILabel!
    @IBOutlet weak var favoriteTotalCount: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        favoriteName.adjustsFontSizeToFitWidth = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
