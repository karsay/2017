//
//  Button_Custom.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/14.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class Button_Custom: UIButton {
    
    /*
     // Only override draw() if you perform custom drawing.
     // An empty implementation adversely affects performance during animation.
     override func draw(_ rect: CGRect) {
     // Drawing code
     }
     */
}
