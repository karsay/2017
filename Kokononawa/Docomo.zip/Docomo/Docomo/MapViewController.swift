//
//  MapViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/16.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit
import MapKit

class MapViewController: UIViewController,MKMapViewDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    var annotation = MKPointAnnotation()
    var name = "金の時計台"
    var longitude : Double?
    var latitude : Double?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //マップ機能のための前準備
        let coordinate = CLLocationCoordinate2DMake(self.latitude!,self.longitude!)
        let span = MKCoordinateSpanMake(0.01, 0.01)
        let region = MKCoordinateRegionMake(coordinate, span)
        mapView.setRegion(region, animated: true)
        annotation.coordinate = CLLocationCoordinate2DMake(self.latitude!,self.longitude!)
        annotation.title = name
        self.mapView.addAnnotation(annotation)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
