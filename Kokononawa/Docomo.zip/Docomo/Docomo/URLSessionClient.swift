//
//  URLSessionGetClient.swift
//  iBot
//
//  Created by Yusk1450 on 2017/08/26.
//  Copyright © 2017年 SAPPOROWORKS. All rights reserved.
//

import UIKit

open class URLSessionClient: NSObject
{
	/* -----------------------------------------------
	 * GETリクエスト
	----------------------------------------------- */
	public func get(url urlString:String, queryItems: [URLQueryItem]?, comp:@escaping (Any) -> Void)
	{
        let application = UIApplication.shared
        application.isNetworkActivityIndicatorVisible = true
        
		var components = URLComponents(string: urlString)
		components?.queryItems = queryItems
		
		let url = components?.url
		let task = URLSession.shared.dataTask(with: url!) { (data, response, err) in
			if let data = data, let response = response {
                
				do {
					let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments)
					comp(json)
                    
				} catch {
                    
					print("Serialize Error")
                    
				}
                
            } else {
                
				print(err ?? "Error")
                
			}
            
            application.isNetworkActivityIndicatorVisible = false

		}
		
		task.resume()
        
	}
	
	/* -----------------------------------------------
	* POSTリクエスト
	----------------------------------------------- */
	public func post(url urlString:String, parameters:[String: Any], comp:@escaping (Any) -> Void)
    {
        let application = UIApplication.shared
        application.isNetworkActivityIndicatorVisible = true
        
		let url = URL(string: urlString)
		var request = URLRequest(url: url!)
		request.httpMethod = "POST"
		
		let parametersString: String = parameters.enumerated().reduce("") { (input, tuple) -> String in
			switch tuple.element.value {
				case let int as Int: return input + tuple.element.key + "=" + String(int) + (parameters.count - 1 > tuple.offset ? "&" : "")
				case let string as String: return input + tuple.element.key + "=" + string + (parameters.count - 1 > tuple.offset ? "&" : "")
				default: return input
                
			}
		}
		
		request.httpBody = parametersString.data(using: String.Encoding.utf8)
		let task = URLSession.shared.dataTask(with: request) { data, response, error in
			if let data = data, let response = response {
				do {
//                    comp(data)
                    print(response)
                    let json = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments)
                    comp(json)
				} catch {
					print("Serialize Error")
				}
			} else {
				print(error ?? "Error")
			}
            
            application.isNetworkActivityIndicatorVisible = false
            
		}
        
		task.resume()
        
	}
    
}

