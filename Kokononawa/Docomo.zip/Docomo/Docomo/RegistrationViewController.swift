//
//  RegistrationViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/09/01.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit
import CoreLocation

class RegistrationViewController: UIViewController, UITextFieldDelegate {
  
  
    @IBOutlet weak var registrationImage: UIImageView!
    @IBOutlet weak var nameInputText: UITextField!
    let sc = UIScrollView()
    var myCoordinate:CLLocationCoordinate2D?
    
    
  //前の画面より画像を設定
  var originalImage : UIImage?

    override func viewDidLoad() {
        super.viewDidLoad()
      
      //Text Fieldのdelegate通知先を自分に設定
      nameInputText.delegate = self
      
      //画面転移時に受け取った画像を表示
      registrationImage.image = originalImage
      
    }
    
    /*-------------キーボードを上に押し上げる処理-----------------*/
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        self.configureObserver()
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        self.removeObserver()
        
    }
    
    func configureObserver() {
        
        let notification = NotificationCenter.default
        notification.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        notification.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
        
    }
    
    func removeObserver() {
        
        let notification = NotificationCenter.default
        notification.removeObserver(self)
        
    }
    @objc func keyboardWillShow(notification: Notification?) {
        
        let rect = (notification?.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue
        let duration: TimeInterval? = notification?.userInfo?[UIKeyboardAnimationDurationUserInfoKey] as? Double
        UIView.animate(withDuration: duration!, animations: { () in
            let transform = CGAffineTransform(translationX: 0, y: -(rect?.size.height)!)
            self.view.transform = transform
            
        })
    }

    // キーボードが消えたときに、画面を戻す
    @objc func keyboardWillHide(notification: Notification?) {
        
        let duration: TimeInterval? = notification?.userInfo?[UIKeyboardAnimationCurveUserInfoKey] as? Double
        UIView.animate(withDuration: duration!, animations: { () in
            
            self.view.transform = CGAffineTransform.identity
        })
    }
  /*------------------------------------------*/
    
    
    //入力が完了した時に呼び出される
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    
        //キーボードを閉じる
        textField.resignFirstResponder()
    
        //入力された文字を取り出す
        let nameKeyWord = textField.text
        print(nameKeyWord!)
    
        //デフォルド動作を行うためtrueを返す
        return true
    
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
  
  @IBAction func registrationActionButton(_ sender: Any) {
    
    let img = registrationImage.image!
    var resImg:UIImage? = nil
    UIGraphicsBeginImageContext(img.size)
    
    registrationImage.image?.draw(in: CGRect(x: 0, y: 0, width: img.size.width, height: img.size.height))
    resImg = UIGraphicsGetImageFromCurrentImageContext()
    
    UIGraphicsEndImageContext()
    
    let imgData = UIImageJPEGRepresentation(resImg!, 0.5)
    let base64 = imgData?.base64EncodedString()
//    print(base64)
    
    let client = URLSessionClient()
//    client.post(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/add",
//                parameters: ["img": base64!]) { (data) in
//                    if let data = data as? Data
//                    {
//                        let str = String(data: data, encoding: String.Encoding.utf8)
//                        print(str!)
//                    }
//                }
    
    if let coordinate = self.myCoordinate
    {
        client.post(url: "http://nichibi-ogaki.sakura.ne.jp/club/sokononawa/public/add",
                    parameters: ["base64_img": base64!,
                                 "name": self.nameInputText.text!,
                                 "latitude": coordinate.latitude.description,
                                 "longitude": coordinate.longitude.description]) { (data) in
                                    print(data)
                                    
                                    DispatchQueue.main.async {
                                        //登録ボタンタップでメイン画面へ
                                        self.performSegue(withIdentifier: "goView", sender: nil)
                                    }
        }

    }
  }


}
