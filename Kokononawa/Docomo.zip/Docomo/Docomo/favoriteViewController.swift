//
//  favoriteViewController.swift
//  Docomo
//
//  Created by AppCircle on 2017/10/19.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class favoriteViewController: UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    var mainImages = ["にのみや"]
    var mainImageTitles = ["学校によくあるやつ"]
    
    @IBOutlet weak var favoriteTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.favoriteTableView.delegate = self
        self.favoriteTableView.dataSource = self
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //セルの個数をimages配列の中身と同数に設定
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return mainImageTitles.count
        
    }
    
    //セルに値を設定するデータソースメソッド
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //セルを取得
        let cell = favoriteTableView.dequeueReusableCell(withIdentifier: "favoriteCell") as! favoriteTableViewCell
        
        //セルに値を設定
        cell.favoriteImage.image = UIImage(named: mainImages[indexPath.row])
        cell.favoriteName.text = mainImageTitles[indexPath.row]
        return cell
        
    }
    
    //渡す画像を保管しておく
    var selectedIndexPath:IndexPath?
    
    //セルの中身を設定
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        
        self.selectedIndexPath = indexPath
        return indexPath
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let nextViewController: DetailViewController = (segue.destination as? DetailViewController)!
        // DetailViewController のselectedImgに選択された画像を設定する
        if let selectedIndexPath = self.selectedIndexPath {
            
            nextViewController.selectedImage = UIImage(named:"\(mainImages[selectedIndexPath.row])")
            self.favoriteTableView.deselectRow(at: selectedIndexPath, animated: true)
            
        }
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
