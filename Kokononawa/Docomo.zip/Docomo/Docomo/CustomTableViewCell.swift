//
//  CustomTableViewCell.swift
//  Docomo
//
//  Created by AppCircle on 2017/09/13.
//  Copyright © 2017年 Ryuken Kashiwagi. All rights reserved.
//

import UIKit

class CustomTableViewCell: UITableViewCell {

    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var mainImageTitle: UILabel!
    @IBOutlet weak var totalCount: UILabel!
    @IBOutlet weak var no1Count: UILabel!
    
    var postId:Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        mainImageTitle.adjustsFontSizeToFitWidth = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

}
